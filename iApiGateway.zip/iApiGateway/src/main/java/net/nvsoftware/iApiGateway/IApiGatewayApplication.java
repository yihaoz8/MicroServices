package net.nvsoftware.iApiGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(IApiGatewayApplication.class, args);
	}

}
